import { View, Text } from "react-native";
import React from "react";

const MovieDetails = () => {
	return (
		<View>
			<Text>MovieDetails</Text>
		</View>
	);
};

export default MovieDetails;
