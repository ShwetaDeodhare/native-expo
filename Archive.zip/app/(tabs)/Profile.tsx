import { View, Text } from "react-native";
import React from "react";

const Profile = () => {
	return (
		<View>
			<Text>profile</Text>
		</View>
	);
};

export default Profile;
