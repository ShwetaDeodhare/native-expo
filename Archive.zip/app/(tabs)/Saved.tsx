import { View, Text } from "react-native";
import React from "react";

const Saved = () => {
	return (
		<View>
			<Text>Saved</Text>
		</View>
	);
};

export default Saved;
